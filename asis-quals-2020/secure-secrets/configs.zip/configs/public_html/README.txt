Put your secret in secret tag and save it as html file.
